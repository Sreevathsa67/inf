import { motion } from "framer-motion";
import SectionHeading from "@/components/SectionHeading";
import Footer from "@/components/Footer";
import { Target, Rocket, Heart } from "lucide-react";

const team = [
  { name: "Arjun Mehta", role: "Lead Organizer", initials: "AM" },
  { name: "Priya Sharma", role: "Technical Head", initials: "PS" },
  { name: "Rahul Verma", role: "Design Lead", initials: "RV" },
  { name: "Sneha Patel", role: "Marketing Head", initials: "SP" },
  { name: "Vikram Singh", role: "Operations", initials: "VS" },
  { name: "Ananya Gupta", role: "Sponsorship Lead", initials: "AG" },
];

const stagger = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
};

const About = () => (
  <div className="min-h-screen bg-background pt-24">
    <div className="container mx-auto px-4 py-16">
      {/* About */}
      <SectionHeading title="About Infothon" subtitle="Where innovation meets impact" />
      <motion.div {...stagger} className="glass-card neon-border p-8 md:p-12 max-w-3xl mx-auto mb-24 text-center">
        <p className="text-muted-foreground leading-relaxed">
          Infothon is a flagship hackathon that brings together students, developers, and innovators to tackle real-world
          challenges. Now in its 6th edition, Infothon has grown into one of the most anticipated tech events,
          fostering creativity, collaboration, and cutting-edge problem solving across disciplines.
        </p>
      </motion.div>

      {/* Team */}
      <SectionHeading title="Organizer Team" subtitle="The people behind the magic" />
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-24">
        {team.map((member, i) => (
          <motion.div
            key={i}
            {...stagger}
            transition={{ delay: i * 0.1 }}
            className="glass-card p-6 text-center hover:neon-border transition-all duration-500 group"
          >
            <div className="w-20 h-20 rounded-full gradient-primary flex items-center justify-center mx-auto mb-4 text-primary-foreground font-display font-bold text-xl group-hover:neon-glow transition-all">
              {member.initials}
            </div>
            <h3 className="font-display text-sm font-bold text-foreground">{member.name}</h3>
            <p className="text-muted-foreground text-xs mt-1">{member.role}</p>
          </motion.div>
        ))}
      </div>

      {/* Vision */}
      <SectionHeading title="Our Vision" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
        {[
          { icon: Target, title: "Innovation", desc: "Pushing boundaries of what's possible through technology and creative thinking." },
          { icon: Rocket, title: "Impact", desc: "Creating solutions that make a tangible difference in communities and industries." },
          { icon: Heart, title: "Collaboration", desc: "Building bridges between disciplines, institutions, and ideas." },
        ].map((item, i) => (
          <motion.div key={i} {...stagger} transition={{ delay: i * 0.15 }} className="glass-card p-8 text-center hover:neon-border transition-all duration-500">
            <item.icon className="w-10 h-10 text-primary mx-auto mb-4" />
            <h3 className="font-display text-lg font-bold text-foreground mb-2">{item.title}</h3>
            <p className="text-muted-foreground text-sm">{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
    <Footer />
  </div>
);

export default About;
