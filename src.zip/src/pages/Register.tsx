import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const Register = () => {
  const [form, setForm] = useState({ name: "", email: "", password: "", college: "" });

  const update = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((prev) => ({ ...prev, [key]: e.target.value }));

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card neon-border p-8 w-full max-w-md"
      >
        <h2 className="font-display text-2xl font-bold text-center text-primary neon-text mb-2">Join Infothon 6.0</h2>
        <p className="text-muted-foreground text-center text-sm mb-8">Create your account to get started</p>

        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
          {[
            { key: "name", label: "Full Name", type: "text", placeholder: "Your full name" },
            { key: "email", label: "Email", type: "email", placeholder: "your@email.com" },
            { key: "password", label: "Password", type: "password", placeholder: "••••••••" },
            { key: "college", label: "College / Organization", type: "text", placeholder: "Your institution" },
          ].map((f) => (
            <div key={f.key}>
              <label className="text-sm font-display text-foreground/80 mb-1 block">{f.label}</label>
              <input
                type={f.type}
                value={form[f.key as keyof typeof form]}
                onChange={update(f.key)}
                required
                className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                placeholder={f.placeholder}
              />
            </div>
          ))}
          <Button variant="hero" className="w-full" type="submit">
            Register
          </Button>
        </form>

        <p className="text-muted-foreground text-center text-sm mt-6">
          Already have an account?{" "}
          <Link to="/login" className="text-primary hover:underline">Login</Link>
        </p>
      </motion.div>
    </div>
  );
};

export default Register;
