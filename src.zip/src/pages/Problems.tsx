import { motion } from "framer-motion";
import SectionHeading from "@/components/SectionHeading";
import Footer from "@/components/Footer";
import { AlertTriangle, Cpu, Shield, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

const problems = [
  {
    id: 1,
    title: "AI-Powered Healthcare Diagnostics",
    description: "Build an AI system that can analyze medical images and patient data to assist doctors in early disease detection. The solution should be accurate, explainable, and accessible in low-resource settings.",
    difficulty: "Hard",
    icon: Cpu,
  },
  {
    id: 2,
    title: "Sustainable Supply Chain Tracker",
    description: "Create a platform that tracks the environmental impact of supply chains in real-time. Enable businesses to make data-driven decisions to reduce their carbon footprint.",
    difficulty: "Medium",
    icon: AlertTriangle,
  },
  {
    id: 3,
    title: "Cybersecurity Threat Detector",
    description: "Develop an intelligent system that detects and responds to cybersecurity threats in real-time using machine learning. The system should minimize false positives while catching zero-day exploits.",
    difficulty: "Hard",
    icon: Shield,
  },
];

const difficultyColor: Record<string, string> = {
  Easy: "text-green-400 border-green-400/30 bg-green-400/10",
  Medium: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10",
  Hard: "text-red-400 border-red-400/30 bg-red-400/10",
};

const Problems = () => {
  return (
    <div className="min-h-screen bg-background pt-24">
      <div className="container mx-auto px-4 py-16">
        <SectionHeading
          title="Problem Statements"
          subtitle="Choose a challenge and build a groundbreaking solution"
        />

        <div className="flex justify-center mb-12">
          <Button variant="neon" size="lg" className="gap-2">
            <Download className="w-5 h-5" />
            Download Template PPT
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {problems.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.15 }}
              className="glass-card p-8 flex flex-col hover:neon-border transition-all duration-500 group"
            >
              <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center mb-6">
                <p.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className={`text-xs font-display uppercase tracking-wider px-3 py-1 rounded-full border w-fit mb-4 ${difficultyColor[p.difficulty]}`}>
                {p.difficulty}
              </span>
              <h3 className="font-display text-lg font-bold text-foreground mb-3">{p.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed flex-1 mb-6">{p.description}</p>
             </motion.div>
           ))}
         </div>
       </div>

       <Footer />
     </div>
   );
 };

 export default Problems;
